const express = require('express');
const postController = require('../controllers/postController');
const router = express.Router();

router.post('/posts', postController.createPost);
router.put('/posts/:postId', postController.editPost);
router.delete('/posts/:postId', postController.deletePost);
router.get('/:userId/posts', postController.getUserPosts);

module.exports = router;

