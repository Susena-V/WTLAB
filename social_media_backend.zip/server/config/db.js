const mysql = require('mysql2');

// Database connection pool configuration
const pool = mysql.createPool({
    host: 'localhost',       // Database host
    user: 'root',            // Database user
    password: 'Sowmi22', // Database password
    database: 'social', // Database name
    port: 3306                // Database port (default for MySQL)
}).promise();

// Check connection status
pool.getConnection((err, connection) => {
    if (err) {
        console.error('Database connection failed:', err.message);
    } else {
        console.log('Database connected successfully');
        connection.release();
    }
});

module.exports = pool;
