const db = require('../config/db');

// Follow a user
exports.followUser = async (req, res) => {
    const followerId = req.body.followerId; // ID of the current user
    const followingId = req.body.followingId; // ID of the user to follow

    try {
        await db.execute('INSERT INTO follows (follower_id, following_id) VALUES (?, ?)', [followerId, followingId]);
        res.status(201).json({ message: 'User followed successfully' });
    } catch (err) {
        res.status(500).json({ message: 'Error following user', error: err.message });
    }
};

// Unfollow a user
exports.unfollowUser = async (req, res) => {
    const followerId = req.body.followerId;
    const followingId = req.body.followingId;

    try {
        await db.execute('DELETE FROM follows WHERE follower_id = ? AND following_id = ?', [followerId, followingId]);
        res.status(200).json({ message: 'User unfollowed successfully' });
    } catch (err) {
        res.status(500).json({ message: 'Error unfollowing user', error: err.message });
    }
};

// Get followers of a user
exports.getFollowers = async (req, res) => {
    const userId = req.params.userId;

    try {
        const [followers] = await db.execute(`
            SELECT users.id, users.username FROM users
            JOIN follows ON users.id = follows.follower_id
            WHERE follows.following_id = ?
        `, [userId]);
        res.status(200).json(followers);
    } catch (err) {
        res.status(500).json({ message: 'Error fetching followers', error: err.message });
    }
};

// Get following of a user
exports.getFollowing = async (req, res) => {
    const userId = req.params.userId;

    try {
        const [following] = await db.execute(`
            SELECT users.id, users.username FROM users
            JOIN follows ON users.id = follows.following_id
            WHERE follows.follower_id = ?
        `, [userId]);
        res.status(200).json(following);
    } catch (err) {
        res.status(500).json({ message: 'Error fetching following list', error: err.message });
    }
};

