const db = require('../config/db');

// Create a new post
exports.createPost = async (req, res) => {
    const userId = req.body.userId;
    const content = req.body.content;

    try {
        const [result] = await db.execute(
            'INSERT INTO posts (user_id, content) VALUES (?, ?)', 
            [userId, content]
        );
        res.status(201).json({ message: 'Post created successfully', postId: result.insertId });
    } catch (err) {
        res.status(500).json({ message: 'Error creating post', error: err.message });
    }
};

// Edit a post
exports.editPost = async (req, res) => {
    const postId = req.params.postId;
    const content = req.body.content;

    try {
        await db.execute(
            'UPDATE posts SET content = ? WHERE id = ?', 
            [content, postId]
        );
        res.status(200).json({ message: 'Post updated successfully' });
    } catch (err) {
        res.status(500).json({ message: 'Error updating post', error: err.message });
    }
};

// Delete a post
exports.deletePost = async (req, res) => {
    const postId = req.params.postId;

    try {
        await db.execute('DELETE FROM posts WHERE id = ?', [postId]);
        res.status(200).json({ message: 'Post deleted successfully' });
    } catch (err) {
        res.status(500).json({ message: 'Error deleting post', error: err.message });
    }
};

// Get all posts by a user
exports.getUserPosts = async (req, res) => {
    const userId = req.params.userId;

    try {
        const [posts] = await db.execute('SELECT * FROM posts WHERE user_id = ?', [userId]);
        res.status(200).json(posts);
    } catch (err) {
        res.status(500).json({ message: 'Error fetching posts', error: err.message });
    }
};
