// src/components/BlogForm.js
import React, { useState, useEffect } from 'react';

function BlogForm({ onSubmit, currentPost }) {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [image, setImage] = useState(null);

  useEffect(() => {
    if (currentPost) {
      setTitle(currentPost.title);
      setContent(currentPost.content);
      setImage(currentPost.image);
    }
  }, [currentPost]);

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit({ title, content, image });
    setTitle('');
    setContent('');
    setImage(null);
  };

  const handleImageUpload = (e) => {
    const file = e.target.files[0];
    const reader = new FileReader();
    reader.onloadend = () => {
      setImage(reader.result); // Converting to base64 string
    };
    reader.readAsDataURL(file);
  };

  return (
    <form onSubmit={handleSubmit} className="blog-form">
      <input
        type="text"
        placeholder="Title"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        required
      />
      <textarea
        placeholder="Write your content here..."
        value={content}
        onChange={(e) => setContent(e.target.value)}
        required
      />
      <input type="file" accept="image/*" onChange={handleImageUpload} />
      {image && <img src={image} alt="Preview" width="100" />}
      <button type="submit">{currentPost ? 'Update Post' : 'Create Post'}</button>
    </form>
  );
}

export default BlogForm;
