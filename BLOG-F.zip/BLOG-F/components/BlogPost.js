// src/components/BlogPost.js
import React from 'react';

function BlogPost({ post, onEdit, onDelete }) {
  return (
    <div className="blog-post">
      <h2>{post.title}</h2>
      <p>{post.content}</p>
      {post.image && <img src={post.image} alt="Blog Post" width="200" />}
      <button onClick={() => onEdit(post)}>Edit</button>
      <button onClick={() => onDelete(post.id)}>Delete</button>
    </div>
  );
}

export default BlogPost;
