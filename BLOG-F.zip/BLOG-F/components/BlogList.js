// src/components/BlogList.js
import React from 'react';
import BlogPost from './BlogPost';

function BlogList({ posts, onEdit, onDelete }) {
  return (
    <div className="blog-list">
      {posts.map((post) => (
        <BlogPost key={post.id} post={post} onEdit={onEdit} onDelete={onDelete} />
      ))}
    </div>
  );
}

export default BlogList;
