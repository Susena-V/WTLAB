// src/App.js
import React, { useState } from 'react';
import BlogForm from './components/BlogForm';
import BlogList from './components/BlogList';
import './App.css';

function App() {
  const [posts, setPosts] = useState([]);
  const [currentPost, setCurrentPost] = useState(null);

  const addOrUpdatePost = (post) => {
    if (currentPost) {
      setPosts(posts.map((p) => (p.id === currentPost.id ? { ...post, id: currentPost.id } : p)));
      setCurrentPost(null);
    } else {
      setPosts([...posts, { ...post, id: Date.now() }]);
    }
  };

  const editPost = (post) => {
    setCurrentPost(post);
  };

  const deletePost = (id) => {
    setPosts(posts.filter((post) => post.id !== id));
  };

  return (
    <div className="App">
      <h1>Blog Post App</h1>
      <BlogForm onSubmit={addOrUpdatePost} currentPost={currentPost} />
      <BlogList posts={posts} onEdit={editPost} onDelete={deletePost} />
    </div>
  );
}

export default App;
