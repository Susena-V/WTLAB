// Service to manage cart functionality
const CartService = {
    addItem: (cart, item) => {
      return [...cart, item];
    },
  
    removeItem: (cart, itemId) => {
      return cart.filter((item) => item.id !== itemId);
    },
  
    getCartTotal: (cart) => {
      return cart.reduce((total, item) => total + item.price, 0);
    },
  };
  
  export default CartService;
  