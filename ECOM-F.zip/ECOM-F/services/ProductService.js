// Service to manage product-related operations
const ProductService = {
    getProduct: (id) => {
      // Logic to fetch a product by its ID (e.g., API call)
      return {
        id,
        name: `Product ${id}`,
        description: 'This is a great product.',
        price: 29.99,
        image: 'https://via.placeholder.com/150',
      };
    },
  
    getAllProducts: () => {
      // Logic to fetch all products (e.g., API call)
      return [
        { id: 1, name: 'Product 1', price: 19.99, image: 'https://via.placeholder.com/150' },
        { id: 2, name: 'Product 2', price: 29.99, image: 'https://via.placeholder.com/150' },
      ];
    },
  };
  
  export default ProductService;
  