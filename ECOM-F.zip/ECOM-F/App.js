import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { CartProvider } from './context/CartContext';
import Navbar from './pages/Navbar'; // Import Navbar

// Import your pages
import Home from './pages/Home';
import CartPage from './pages/CartPage';
import ProductPage from './pages/ProductPage';
import Login from './pages/Login';
import SignUp from './pages/SignUp';
import OrderHistory from './pages/OrderHistory'; // Import OrderHistory page

function App() {
  return (
    <CartProvider>
      <Router>
        <div className="App">
          <Navbar /> {/* Include Navbar */}
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/cart" element={<CartPage />} />
            <Route path="/product/:id" element={<ProductPage />} />
            <Route path="/login" element={<Login />} />
            <Route path="/signup" element={<SignUp />} />
            <Route path="/order-history" element={<OrderHistory />} />
          </Routes>
        </div>
      </Router>
    </CartProvider>
  );
}

export default App;
