import React from 'react';
import { useCart } from '../context/CartContext'; // Import useCart

const CartPage = () => {
  const { cart, removeFromCart } = useCart(); // Destructure cart and removeFromCart from context

  return (
    <div className="cart-page">
      <h1>Your Cart</h1>
      {cart.length === 0 ? (
        <p>Your cart is empty.</p>
      ) : (
        <div>
          {cart.map((item) => (
            <div key={item.id} className="cart-item">
              <img src={item.image} alt={item.name} />
              <h3>{item.name}</h3>
              <p>{item.description}</p>
              <p>${item.price}</p>
              <button onClick={() => removeFromCart(item.id)}>Remove</button>
            </div>
          ))}
          <div>
            <h3>Total: ${cart.reduce((total, item) => total + item.price, 0)}</h3>
          </div>
        </div>
      )}
    </div>
  );
};

export default CartPage;
