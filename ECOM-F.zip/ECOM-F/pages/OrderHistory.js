import React from 'react';

const OrderHistory = () => {
  const orders = [
    { id: 1, date: '2024-10-01', total: 50 },
    { id: 2, date: '2024-10-05', total: 30 },
  ];

  return (
    <div className="order-history">
      <h1>Your Order History</h1>
      {orders.length === 0 ? (
        <p>You have no previous orders.</p>
      ) : (
        <div>
          {orders.map((order) => (
            <div key={order.id} className="order-item">
              <p>Order ID: {order.id}</p>
              <p>Order Date: {order.date}</p>
              <p>Total: ${order.total}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default OrderHistory;
