import React from 'react';
import { useCart } from '../context/CartContext'; // Import useCart to access cart context

const ProductCard = ({ product }) => {
  const { addToCart } = useCart(); // Destructure the addToCart function from context

  const handleAddToCart = () => {
    addToCart(product); // Add product to the cart
  };

  return (
    <div className="product-card">
      <img src={product.image} alt={product.name} />
      <h2>{product.name}</h2>
      <p>{product.description}</p>
      <p>${product.price}</p>
      <button onClick={handleAddToCart}>Add to Cart</button>
    </div>
  );
};

export default ProductCard;
