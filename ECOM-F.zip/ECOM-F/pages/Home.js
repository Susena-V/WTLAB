import React from 'react';
import { Link } from 'react-router-dom';
import ProductCard from './ProductCard';

const Home = () => {
  const products = [
    {
      id: 1,
      name: 'Product 1',
      description: 'Description of product 1',
      price: 10,
      image: 'path/to/image1.jpg',
    },
    {
      id: 2,
      name: 'Product 2',
      description: 'Description of product 2',
      price: 20,
      image: 'path/to/image2.jpg',
    },
  ];

  return (
    <div className="home">
      <h1>Product Listings</h1>
      <div className="product-list">
        {products.map((product) => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>

      <div>
        {/* Link to CartPage */}
        <Link to="/cart">Go to Cart</Link>

        {/* Link to CheckoutPage */}
        <Link to="/checkout">Proceed to Checkout</Link>
      </div>
    </div>
  );
};

export default Home;
