import React from 'react';
import { useParams } from 'react-router-dom';

const ProductPage = () => {
  const { id } = useParams();
  // Fetch product details from an API based on the id

  return (
    <div>
      <h2>Product Details</h2>
      <p>Product ID: {id}</p>
      {/* Product details will be displayed here */}
    </div>
  );
};

export default ProductPage;
