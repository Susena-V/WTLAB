// App.js
import React, { useState } from 'react';
import JobListing from './JobListing';
import ApplicationForm from './ApplicationForm';

const App = () => {
  const [jobs] = useState([
    { id: 1, title: 'Software Engineer', description: 'Develop applications' },
    { id: 2, title: 'Product Manager', description: 'Manage product lifecycle' },
  ]);
  
  const [selectedJob, setSelectedJob] = useState(null);
  const [applications, setApplications] = useState([]);

  const handleApply = (job) => {
    setSelectedJob(job);
  };

  const handleApplicationSubmit = (application) => {
    setApplications([...applications, application]);
    setSelectedJob(null);
    alert('Application submitted successfully!');
  };

  return (
    <div className="App">
      {!selectedJob ? (
        <JobListing jobs={jobs} onApply={handleApply} />
      ) : (
        <ApplicationForm job={selectedJob} onSubmit={handleApplicationSubmit} />
      )}
      <h2>Your Applications</h2>
      <ul>
        {applications.map((app, index) => (
          <li key={index}>
            {app.name} applied for {jobs.find(job => job.id === app.jobId)?.title}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default App;