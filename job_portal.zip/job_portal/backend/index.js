const express = require("express");
const app = express();
const port = 3000;
const cors = require("cors");
const db = require("./db");
const bodyParser = require("body-parser");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
require('dotenv').config();

app.use(bodyParser.json());
app.use(cors());
app.use(express.json());

const JWT_SECRET = process.env.JWT_SECRET || "your_secret_key";

// Middleware to authenticate token
const authenticateToken = (req, res, next) => {
    const token = req.headers["authorization"];
    if (!token) return res.sendStatus(401);

    jwt.verify(token, JWT_SECRET, (err, user) => {
        if (err) return res.sendStatus(403);
        req.user = user;
        next();
    });
};

// Signup route
app.post("/signup", async (req, res) => {
    const { username, password, email, role } = req.body;

    const userCheckQuery = "SELECT * FROM users WHERE username = ?";
    db.query(userCheckQuery, [username], async (err, rows) => {
        if (err) return res.status(500).json({ error: "Error checking user" });
        if (rows.length > 0) return res.status(400).json({ error: "User already exists" });

        const hashedPassword = await bcrypt.hash(password, 10);
        const query = "INSERT INTO users (username, password, email, role) VALUES (?, ?, ?, ?)";

        db.query(query, [username, hashedPassword, email, role], (err, results) => {
            if (err) {
                return res.status(500).json({ error: "Error creating user" });
            }
            res.status(201).json({ message: "User created successfully", userId: results.insertId });
        });
    });
});

// Login route
app.post("/login", (req, res) => {
    const { username, password } = req.body;

    const query = "SELECT * FROM users WHERE username = ?";
    db.query(query, [username], async (err, results) => {
        if (err || results.length === 0) {
            return res.status(400).json({ error: "Invalid credentials" });
        }

        const user = results[0];
        const isPasswordValid = await bcrypt.compare(password, user.password);
        if (!isPasswordValid) {
            return res.status(400).json({ error: "Invalid credentials" });
        }

        const token = jwt.sign({ id: user.id, role: user.role }, JWT_SECRET, { expiresIn: "1h" });
        res.json({ message: "Login successful", token });
    });
});

// Create a job posting (Employer)
app.post("/jobs", authenticateToken, (req, res) => {
    const { title, description } = req.body;
    const employerId = req.user.id;

    if (req.user.role !== "employer") {
        return res.status(403).json({ error: "Only employers can create job postings" });
    }

    const query = "INSERT INTO jobs (title, description, employer_id) VALUES (?, ?, ?)";
    db.query(query, [title, description, employerId], (err, results) => {
        if (err) return res.status(500).json({ error: "Error creating job posting" });
        res.status(201).json({ message: "Job posted successfully", jobId: results.insertId });
    });
});

// Get all job postings
app.get("/jobs", (req, res) => {
    const query = "SELECT * FROM jobs";
    db.query(query, (err, results) => {
        if (err) return res.status(500).json({ error: "Error retrieving job postings" });
        res.json(results);
    });
});

// Apply for a job (Job seeker)
app.post("/applications", authenticateToken, (req, res) => {
    const { jobId } = req.body;
    const userId = req.user.id;

    if (req.user.role !== "job_seeker") {
        return res.status(403).json({ error: "Only job seekers can apply for jobs" });
    }

    const query = "INSERT INTO applications (job_id, user_id) VALUES (?, ?)";
    db.query(query, [jobId, userId], (err, results) => {
        if (err) return res.status(500).json({ error: "Error applying for job" });
        res.status(201).json({ message: "Job application submitted successfully", applicationId: results.insertId });
    });
});

// Get applications for a job (Employer)
app.get("/jobs/:id/applications", authenticateToken, (req, res) => {
    const jobId = req.params.id;

    if (req.user.role !== "employer") {
        return res.status(403).json({ error: "Only employers can view job applications" });
    }

    const query = `SELECT applications.id, applications.status, users.username, users.email 
                   FROM applications 
                   JOIN users ON applications.user_id = users.id 
                   WHERE applications.job_id = ? AND users.role = 'job_seeker'`;

    db.query(query, [jobId], (err, results) => {
        if (err) return res.status(500).json({ error: "Error retrieving applications" });
        res.json(results);
    });
});

// Update application status (Employer)
app.put("/applications/:id", authenticateToken, (req, res) => {
    const applicationId = req.params.id;
    const { status } = req.body;

    if (req.user.role !== "employer") {
        return res.status(403).json({ error: "Only employers can update application status" });
    }

    const query = "UPDATE applications SET status = ? WHERE id = ?";
    db.query(query, [status, applicationId], (err, results) => {
        if (err) return res.status(500).json({ error: "Error updating application status" });
        res.json({ message: "Application status updated successfully" });
    });
});

// Start the server
app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});
