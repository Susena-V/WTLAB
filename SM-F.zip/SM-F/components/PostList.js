// src/components/PostList.js
import React from 'react';
import './PostList.css';

function PostList({ posts, setPosts }) {
  const handleDelete = (postId) => {
    setPosts(posts.filter((post) => post.id !== postId));
  };

  return (
    <div className="post-list">
      <h3>Your Posts</h3>
      {posts.map((post) => (
        <div key={post.id} className="post-item">
          <p>{post.content}</p>
          <button onClick={() => handleDelete(post.id)} className="delete-button">
            Delete
          </button>
        </div>
      ))}
    </div>
  );
}

export default PostList;
