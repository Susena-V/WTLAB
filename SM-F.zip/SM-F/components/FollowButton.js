import React, { useState } from 'react';
import api from '../api/api';
import './FollowButton.css';

const FollowButton = ({ userId, isFollowing, onFollowToggle }) => {
    const [following, setFollowing] = useState(isFollowing);

    const handleFollowToggle = async () => {
        try {
            if (following) {
                await api.post('/follow/unfollow', { followingId: userId });
            } else {
                await api.post('/follow/follow', { followingId: userId });
            }
            setFollowing(!following);
            onFollowToggle(!following);
        } catch (error) {
            console.error('Error toggling follow status:', error);
        }
    };

    return (
        <button className={`follow-button ${following ? 'following' : ''}`} onClick={handleFollowToggle}>
            {following ? 'Unfollow' : 'Follow'}
        </button>
    );
};

export default FollowButton;
