// src/components/FollowersList.js
import React from 'react';
import './FollowersList.css';

function FollowersList({ followers }) {
  return (
    <div className="followers-list">
      <h3>Followers</h3>
      <ul>
        {followers.map((follower, index) => (
          <li key={index}>{follower}</li>
        ))}
      </ul>
    </div>
  );
}

export default FollowersList;
