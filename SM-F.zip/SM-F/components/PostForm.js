// src/components/PostForm.js
import React, { useState } from 'react';
import './PostForm.css';

function PostForm({ setPosts }) {
  const [postContent, setPostContent] = useState('');

  const handlePostSubmit = (e) => {
    e.preventDefault();
    if (postContent) {
      setPosts((prevPosts) => [
        ...prevPosts,
        { id: prevPosts.length + 1, content: postContent },
      ]);
      setPostContent('');
    }
  };

  return (
    <div className="post-form">
      <textarea
        value={postContent}
        onChange={(e) => setPostContent(e.target.value)}
        placeholder="Write your post..."
      ></textarea>
      <button onClick={handlePostSubmit}>Post</button>
    </div>
  );
}

export default PostForm;
