// src/App.js
import React, { useState } from 'react';
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';
import './App.css';
import PostForm from './components/PostForm';
import PostList from './components/PostList';
import FollowButton from './components/FollowButton';
import FollowersList from './components/FollowersList';

// Sample data for posts and followers
const initialPosts = [
  { id: 1, content: 'This is my first post!' },
  { id: 2, content: 'Here is another post.' },
];

const initialFollowers = ['user1', 'user2', 'user3'];

function App() {
  const [posts, setPosts] = useState(initialPosts);
  const [followers, setFollowers] = useState(initialFollowers);
  const [following, setFollowing] = useState(false);

  return (
    <Router>
      <div className="App">
        <h1>Social Media Platform</h1>
        
        {/* Navigation Bar */}
        <nav>
          <Link to="/">Home</Link> | <Link to="/profile">Profile</Link>
        </nav>

        {/* Routes for different pages */}
        <Routes>
          {/* Home Page */}
          <Route path="/" element={<HomePage posts={posts} setPosts={setPosts} />} />

          {/* Profile Page */}
          <Route path="/profile" element={<ProfilePage followers={followers} following={following} setFollowing={setFollowing} />} />
        </Routes>
      </div>
    </Router>
  );
}

// Home Page Component
function HomePage({ posts, setPosts }) {
  return (
    <div>
      <h2>Home Page</h2>
      <PostForm setPosts={setPosts} />
      <PostList posts={posts} setPosts={setPosts} />
    </div>
  );
}

// Profile Page Component
function ProfilePage({ followers, following, setFollowing }) {
  return (
    <div>
      <h2>Profile Page</h2>
      <FollowButton following={following} setFollowing={setFollowing} />
      <FollowersList followers={followers} />
    </div>
  );
}

export default App;
