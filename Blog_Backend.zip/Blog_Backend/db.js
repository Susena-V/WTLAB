const mysql = require('mysql2');

// Create a MySQL connection pool
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '12#hridyA',
    database: 'Blog_Posts',
});
db.connect(err => {
    if (err) {
      console.error('Error connecting to the database:', err);
      process.exit(1);
    } else {
      console.log('Connected to MySQL database');
    }
  });
  
// Export the database connection
module.exports = db;
