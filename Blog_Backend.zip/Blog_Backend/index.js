const express = require('express');
const bodyParser = require('body-parser');
const db = require('./db'); // Import the database connection

const app = express();
app.use(bodyParser.json());

// Route to create a new blog post
app.post('/posts', (req, res) => {
    const { title, content, media, categories, tags } = req.body;

    db.query('INSERT INTO blog_posts (title, content) VALUES (?, ?)', [title, content], (err, result) => {
        if (err) {
            return res.status(500).send('Error creating blog post');
        }
        
        const postId = result.insertId;

        // Insert media if provided
        if (media && media.length > 0) {
            const mediaQueries = media.map(m => [postId, m.url, m.type]);
            db.query('INSERT INTO media_uploads (post_id, media_url, media_type) VALUES ?', [mediaQueries], err => {
                if (err) console.error('Error inserting media:', err);
            });
        }

        // Insert categories
        if (categories && categories.length > 0) {
            categories.forEach(category => {
                db.query('INSERT INTO categories (category_name) VALUES (?) ON DUPLICATE KEY UPDATE category_id = LAST_INSERT_ID(category_id)', [category], (err, result) => {
                    if (!err) {
                        const categoryId = result.insertId;
                        db.query('INSERT INTO post_categories (post_id, category_id) VALUES (?, ?)', [postId, categoryId], err => {
                            if (err) console.error('Error associating category:', err);
                        });
                    }
                });
            });
        }

        // Insert tags
        if (tags && tags.length > 0) {
            tags.forEach(tag => {
                db.query('INSERT INTO tags (tag_name) VALUES (?) ON DUPLICATE KEY UPDATE tag_id = LAST_INSERT_ID(tag_id)', [tag], (err, result) => {
                    if (!err) {
                        const tagId = result.insertId;
                        db.query('INSERT INTO post_tags (post_id, tag_id) VALUES (?, ?)', [postId, tagId], err => {
                            if (err) console.error('Error associating tag:', err);
                        });
                    }
                });
            });
        }

        res.status(201).send({ message: 'Blog post created', postId });
    });
});

// Route to update a blog post
app.put('/posts/:id', (req, res) => {
    const postId = req.params.id;
    const { title, content } = req.body;

    // Validate request body
    if (!title || !content) {
        return res.status(400).send('Title and content are required');
    }

    // Update the blog post in the database
    db.query('UPDATE blog_posts SET title = ?, content = ? WHERE post_id = ?', [title, content, postId], (err, result) => {
        if (err) {
            console.error('Error updating blog post:', err);
            return res.status(500).send('Error updating blog post');
        }

        if (result.affectedRows === 0) {
            // This means no post with the given post_id was found
            return res.status(404).send('Blog post not found');
        }

        res.send({ message: 'Blog post updated' });
    });
});


// Route to get all blog posts with categories and tags
app.get('/posts', (req, res) => {
    db.query(`
        SELECT bp.post_id, bp.title, bp.content, bp.created_at, 
               GROUP_CONCAT(DISTINCT c.category_name) AS categories,
               GROUP_CONCAT(DISTINCT t.tag_name) AS tags
        FROM blog_posts bp
        LEFT JOIN post_categories pc ON bp.post_id = pc.post_id
        LEFT JOIN categories c ON pc.category_id = c.category_id
        LEFT JOIN post_tags pt ON bp.post_id = pt.post_id
        LEFT JOIN tags t ON pt.tag_id = t.tag_id
        GROUP BY bp.post_id
    `, (err, results) => {
        if (err) {
            return res.status(500).send('Error retrieving blog posts');
        }
        if (results.length === 0) {
            return res.status(404).send('No blog posts found');
        }
        res.send(results);
    });
});


// Route to delete a blog post
app.delete('/posts/:id', (req, res) => {
    const postId = req.params.id;

    db.query('DELETE FROM post_categories WHERE post_id = ?', [postId], err => {
        if (err) console.error('Error deleting post categories:', err);
    });
    db.query('DELETE FROM post_tags WHERE post_id = ?', [postId], err => {
        if (err) console.error('Error deleting post tags:', err);
    });
    db.query('DELETE FROM media_uploads WHERE post_id = ?', [postId], err => {
        if (err) console.error('Error deleting media:', err);
    });
    db.query('DELETE FROM blog_posts WHERE post_id = ?', [postId], (err, result) => {
        if (err) {
            return res.status(500).send('Error deleting blog post');
        }
        res.send({ message: 'Blog post deleted' });
    });
});

// Route to get a blog post with categories and tags
app.get('/posts/:id', (req, res) => {
    const postId = req.params.id;

    db.query(`
        SELECT bp.post_id, bp.title, bp.content, bp.created_at, 
               GROUP_CONCAT(DISTINCT c.category_name) AS categories,
               GROUP_CONCAT(DISTINCT t.tag_name) AS tags
        FROM blog_posts bp
        LEFT JOIN post_categories pc ON bp.post_id = pc.post_id
        LEFT JOIN categories c ON pc.category_id = c.category_id
        LEFT JOIN post_tags pt ON bp.post_id = pt.post_id
        LEFT JOIN tags t ON pt.tag_id = t.tag_id
        WHERE bp.post_id = ?
        GROUP BY bp.post_id
    `, [postId], (err, results) => {
        if (err) {
            return res.status(500).send('Error retrieving blog post');
        }
        if (results.length === 0) {
            return res.status(404).send('Blog post not found');
        }
        res.send(results[0]);
    });
});

// Start the Express server
const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
