import React from 'react';

const Checkout = () => {
  return (
    <div>
      <h1>Checkout</h1>
      <button>Proceed to Payment</button>
    </div>
  );
};

export default Checkout;
