import React, { useEffect, useState } from 'react';
import axios from 'axios';

const Cart = () => {
  const [cartItems, setCartItems] = useState([]);

  useEffect(() => {
    // Fetch cart items from backend API
    axios.get('http://localhost:5001/api/cart', { params: { userId: 1 } })
      .then(response => setCartItems(response.data))
      .catch(error => console.error('Error fetching cart items', error));
  }, []);

  const handleRemoveFromCart = (productId) => {
    axios.delete('http://localhost:5001/api/cart/delete', {
      data: { userId: 1, productId }
    }).then(() => {
      setCartItems(cartItems.filter(item => item.product_id !== productId));
    }).catch(err => console.error('Error removing from cart', err));
  };

  return (
    <div>
      <h1>Your Cart</h1>
      <div className="cart-items">
        {cartItems.map(item => (
          <div key={item.product_id} className="cart-item">
            <p>{item.name} - {item.quantity} x ${item.price}</p>
            <button onClick={() => handleRemoveFromCart(item.product_id)}>Remove</button>
          </div>
        ))}
      </div>
      <button>Checkout</button>
    </div>
  );
};

export default Cart;
