import React from 'react';
import axios from 'axios';

const Product = ({ product }) => {
  const handleAddToCart = () => {
    // Handle add to cart functionality
    axios.post('http://localhost:5000/api/cart/add', {
      userId: 1, // Example user ID, you can manage this dynamically
      productId: product.id,
      quantity: 1
    }).then(() => alert('Product added to cart'))
      .catch(err => console.error('Error adding to cart', err));
  };

  return (
    <div className="product">
      <img src={product.imageUrl} alt={product.name} />
      <h3>{product.name}</h3>
      <p>${product.price}</p>
      <button onClick={handleAddToCart}>Add to Cart</button>
    </div>
  );
};

export default Product;
