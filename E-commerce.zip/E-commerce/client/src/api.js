import axios from 'axios';

// Set up the base URL for the backend API
const API_BASE_URL = 'http://localhost:5000/api';

// Configure axios to handle requests
const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Example API calls

// Register a new user
export const registerUser = async (userData) => {
  try {
    const response = await api.post('/auth/signup', userData);
    return response.data;
  } catch (error) {
    throw new Error('Error during registration');
  }
};

// Log in a user
export const loginUser = async (userData) => {
  try {
    const response = await api.post('/auth/login', userData);
    return response.data;
  } catch (error) {
    throw new Error('Invalid credentials');
  }
};

// Get all products
export const getProducts = async () => {
  try {
    const response = await api.get('/products');
    return response.data;
  } catch (error) {
    throw new Error('Error fetching products');
  }
};

// Get products in the cart
export const getCart = async (userId) => {
  try {
    const response = await api.get(`/cart/${userId}`);
    return response.data;
  } catch (error) {
    throw new Error('Error fetching cart items');
  }
};

// Add a product to the cart
export const addToCart = async (productData) => {
  try {
    const response = await api.post('/cart', productData);
    return response.data;
  } catch (error) {
    throw new Error('Error adding product to cart');
  }
};

// Remove a product from the cart
export const removeFromCart = async (productId) => {
  try {
    const response = await api.delete('/cart', { data: { productId } });
    return response.data;
  } catch (error) {
    throw new Error('Error removing product from cart');
  }
};

// Proceed with checkout
export const checkout = async (userId) => {
  try {
    const response = await api.post('/orders/checkout', { userId });
    return response.data;
  } catch (error) {
    throw new Error('Error during checkout');
  }
};

export default api;
