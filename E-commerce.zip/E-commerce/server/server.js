require('dotenv').config(); // Load environment variables

const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const authRoutes = require('./routes/authRoutes');
const cartRoutes = require('./routes/cartRoutes');
const orderRoutes = require('./routes/orderRoutes');  // Add order routes here
const productsRoutes = require('./routes/productsRoutes');  // Import products route

const app = express();

// Middleware
app.use(cors());
app.use(bodyParser.json());

// Use routes
app.use('/api/auth', authRoutes);
app.use('/api/cart', cartRoutes);
app.use('/api/orders', orderRoutes);
app.use('/api', productsRoutes);  // Use the products route


// Add route for the root path
app.get('/', (req, res) => {
  res.send('Welcome to the E-commerce API');
});

// Start the server
app.listen(5001, () => {
  console.log('Server running on port 5001');
});
