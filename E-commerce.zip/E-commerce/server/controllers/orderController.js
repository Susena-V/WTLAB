const db = require('../models/db');

exports.checkout = (req, res) => {
    const { userId } = req.body;

    // Query to calculate total directly from the cart and products tables
    db.query(
        `SELECT SUM(products.price * cart.quantity) AS total
         FROM cart
         JOIN products ON cart.product_id = products.id
         WHERE cart.user_id = ?`,
        [userId],
        (error, results) => {
            if (error) {
                console.error("Error calculating total:", error);
                return res.status(500).send('Error calculating total');
            }

            const total = results[0].total;

            // Check if total is null (i.e., if cart is empty)
            if (!total) {
                return res.status(400).send('Cart is empty');
            }

            console.log("Calculated Total:", total);

            // Clear the cart after checking out
            db.query(
                'DELETE FROM cart WHERE user_id = ?',
                [userId],
                (clearError) => {
                    if (clearError) {
                        console.error("Clear Error:", clearError);
                        return res.status(500).send('Failed to clear cart');
                    }

                    // Return the response with success message and total
                    res.status(200).json({
                        message: 'Checkout successful',
                        total
                    });
                }
            );
        }
    );
};
