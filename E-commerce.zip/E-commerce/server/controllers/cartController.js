const db = require('../models/db');

// Add product to cart
const addToCart = (req, res) => {
  const { user_id, product_id, quantity } = req.body;

  // Validate if all parameters are provided
  if (!user_id || !product_id || !quantity) {
    return res.status(400).json({ error: 'User ID, Product ID, and Quantity are required' });
  }

  db.query(
    'INSERT INTO cart (user_id, product_id, quantity) VALUES (?, ?, ?)',
    [user_id, product_id, quantity],
    (err, result) => {
      if (err) {
        console.error('Error adding product to cart:', err);
        return res.status(500).json({ error: err.message });
      }
      res.status(201).json({ message: 'Product added to cart' });
    }
  );
};

// View cart
const viewCart = (req, res) => {
  const { user_id } = req.params;

  // Validate user_id parameter
  if (!user_id) {
    return res.status(400).json({ error: 'User ID is required' });
  }

  db.query(
    'SELECT cart.id, cart.product_id, cart.quantity, products.name, products.price FROM cart JOIN products ON cart.product_id = products.id WHERE cart.user_id = ?',
    [user_id],
    (err, results) => {
      if (err) {
        console.error('Error fetching cart items:', err);
        return res.status(500).json({ error: err.message });
      }
      res.status(200).json(results);
    }
  );
};

// Remove product from cart
const removeFromCart = (req, res) => {
  const { cart_id } = req.params;

  // Validate cart_id parameter
  if (!cart_id) {
    return res.status(400).json({ error: 'Cart ID is required' });
  }

  db.query('DELETE FROM cart WHERE id = ?', [cart_id], (err, result) => {
    if (err) {
      console.error('Error removing product from cart:', err);
      return res.status(500).json({ error: err.message });
    }
    res.status(200).json({ message: 'Product removed from cart' });
  });
};

module.exports = {
  addToCart,
  viewCart,
  removeFromCart,
};
