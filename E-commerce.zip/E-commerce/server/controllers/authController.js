// server/controllers/authController.js
const db = require('../models/db');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

// Sign Up Handler
const signUp = (req, res) => {
  const { username, email, password } = req.body;

  // Hash password before storing in DB
  bcrypt.hash(password, 10, (err, hashedPassword) => {
    if (err) return res.status(500).json({ error: err.message });

    db.query(
      'INSERT INTO users (username, email, password) VALUES (?, ?, ?)',
      [username, email, hashedPassword],
      (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        res.status(201).json({ message: 'User created successfully' });
      }
    );
  });
};

// Login Handler
const login = (req, res) => {
  const { email, password } = req.body;

  db.query('SELECT * FROM users WHERE email = ?', [email], (err, result) => {
    if (err) return res.status(500).json({ error: err.message });
    if (result.length === 0) return res.status(400).json({ error: 'User not found' });

    // Compare the password with the hash stored in the DB
    bcrypt.compare(password, result[0].password, (err, isMatch) => {
      if (err) return res.status(500).json({ error: err.message });
      if (!isMatch) return res.status(400).json({ error: 'Invalid password' });

      // Generate JWT token
      const token = jwt.sign({ id: result[0].id }, process.env.JWT_SECRET || 'your_jwt_secret', {
        expiresIn: '1h',
      });
      res.status(200).json({ message: 'Login successful', token });
    });
  });
};

module.exports = {
  signUp,
  login,
};
