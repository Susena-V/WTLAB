const express = require('express');
const router = express.Router();
const orderController = require('../controllers/orderController');

// Use the checkout function directly from orderController
router.post('/checkout', orderController.checkout);

module.exports = router;
