// server/routes/cartRoutes.js
const express = require('express');
const router = express.Router();
const { addToCart, viewCart, removeFromCart } = require('../controllers/cartController');

router.post('/', addToCart);   // Add product to cart
router.get('/:user_id', viewCart);  // View cart
router.delete('/:cart_id', removeFromCart);  // Remove product from cart

module.exports = router;
