const express = require('express');
const router = express.Router();
const db = require('../models/db');

// Route to get all products
router.get('/products', (req, res) => {
  db.query('SELECT * FROM products', (err, results) => {
    if (err) return res.status(500).json({ error: err.message });
    res.status(200).json(results); // Send the products as JSON
  });
});

module.exports = router;
