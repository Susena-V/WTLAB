const db = require('../config/db');

exports.createCourse = (req, res) => {
  const { title, description } = req.body;

  db.query(
    'INSERT INTO courses (title, description) VALUES (?, ?)',
    [title, description],
    (err) => {
      if (err) return res.status(500).json({ message: err.message });
      res.status(201).json({ message: 'Course created!' });
    }
  );
};

exports.enrollCourse = (req, res) => {
  const { userId, courseId } = req.body;

  db.query(
    'INSERT INTO enrollments (user_id, course_id) VALUES (?, ?)',
    [userId, courseId],
    (err) => {
      if (err) return res.status(500).json({ message: err.message });
      res.status(201).json({ message: 'Enrolled successfully!' });
    }
  );
};
