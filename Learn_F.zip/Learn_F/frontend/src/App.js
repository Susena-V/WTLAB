import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import Signup from './components/Signup';
import Login from './components/Login';
import Courses from './components/Courses';
import Profile from './components/Profile';
import './styles.css';
import './components/Header.css';
import './components/Footer.css';
import './components/pages.css';
import './components/Forms.css';

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [user, setUser] = useState(null);
  const [enrolledCourses, setEnrolledCourses] = useState([]);

  // On load, check for a session and load courses if a user is logged in
  useEffect(() => {
    const storedUser = localStorage.getItem('user');
    if (storedUser) {
      const parsedUser = JSON.parse(storedUser);
      setUser(parsedUser);
      setIsAuthenticated(true);

      // Load courses specific to this user
      const storedCourses = localStorage.getItem(`${parsedUser.username}_courses`);
      if (storedCourses) {
        setEnrolledCourses(JSON.parse(storedCourses));
      }
    }
  }, []);

  // Login handler: Authenticate and load user-specific courses
  const handleLogin = (userData) => {
    setIsAuthenticated(true);
    setUser(userData);
    localStorage.setItem('user', JSON.stringify(userData)); // Store session user

    // Load or initialize courses for this user
    const storedCourses = localStorage.getItem(`${userData.username}_courses`);
    setEnrolledCourses(storedCourses ? JSON.parse(storedCourses) : []);
  };

  // Logout handler: Clear session but keep user courses in localStorage
  const handleLogout = () => {
    setIsAuthenticated(false);
    setUser(null);
    setEnrolledCourses([]); // Clear courses in state only
    localStorage.removeItem('user'); // Clear session data only
  };

  // Enroll in course: Update user's course list in localStorage
  const enrollInCourse = (course) => {
    const updatedCourses = [...enrolledCourses, course];
    setEnrolledCourses(updatedCourses);
    if (user) {
      localStorage.setItem(`${user.username}_courses`, JSON.stringify(updatedCourses));
    }
  };

  // Unenroll from course: Update user-specific course list in localStorage
  const unenrollFromCourse = (courseId) => {
    const updatedCourses = enrolledCourses.filter(course => course.id !== courseId);
    setEnrolledCourses(updatedCourses);
    if (user) {
      localStorage.setItem(`${user.username}_courses`, JSON.stringify(updatedCourses));
    }
  };

  return (
    <Router>
      <Header isAuthenticated={isAuthenticated} handleLogout={handleLogout} />
      <div className="container">
        <Routes>
          <Route
            path="/signup"
            element={!isAuthenticated ? <Signup handleLogin={handleLogin} /> : <Navigate to="/courses" />}
          />
          <Route
            path="/login"
            element={!isAuthenticated ? <Login handleLogin={handleLogin} /> : <Navigate to="/courses" />}
          />
          <Route
            path="/courses"
            element={isAuthenticated ? (
              <Courses
                enrollInCourse={enrollInCourse}
                enrolledCourses={enrolledCourses}
              />
            ) : (
              <Navigate to="/login" />
            )}
          />
          <Route
            path="/profile"
            element={isAuthenticated ? (
              <Profile
                user={user}
                enrolledCourses={enrolledCourses}
                unenrollFromCourse={unenrollFromCourse}
              />
            ) : (
              <Navigate to="/login" />
            )}
          />
          <Route path="*" element={<Navigate to="/courses" />} />
        </Routes>
      </div>
      <Footer />
    </Router>
  );
}

export default App;
