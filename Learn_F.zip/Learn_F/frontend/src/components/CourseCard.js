import React from 'react';
import '../styles.css';
import './pages.css'

function CourseCard({ course, enrollInCourse, isEnrolled }) {
  return (
    <div className="course-card">
      <h3>{course.title}</h3>
      <p>{course.description}</p>
      {isEnrolled ? (
        <button disabled>Enrolled</button>
      ) : (
        <button onClick={() => enrollInCourse(course)}>Enroll</button>
      )}
    </div>
  );
}

export default CourseCard;
