import React from 'react';
import "./Footer.css";
import '../styles.css';


function Footer() {
  return <footer>© 2024 Learning Platform</footer>;
}

export default Footer;
