import React from 'react';
import CourseCard from './CourseCard';
import '../styles.css';
import './pages.css'

function Courses({ enrollInCourse, enrolledCourses }) {
  const courses = [
    { id: 1, title: 'React for Beginners', description: 'Learn React from scratch' },
    { id: 2, title: 'JavaScript Essentials', description: 'Master JavaScript' },
    { id: 3, title: 'Node.js and Express', description: 'Backend development with Node.js' },
  ];

  return (
    <div>
      <h2>Courses</h2>
      {courses.map((course) => (
        <CourseCard
          key={course.id}
          course={course}
          enrollInCourse={enrollInCourse}
          isEnrolled={enrolledCourses.some((enrolledCourse) => enrolledCourse.id === course.id)}
        />
      ))}
    </div>
  );
}

export default Courses;
