import React from 'react';

const Profile = ({ user, enrolledCourses, unenrollFromCourse }) => {
  // Example data for marks and progress (can be dynamic based on your app's data)
  const getMarks = (courseId) => {
    // This function would return marks for a specific course
    // For now, it returns a random number as a placeholder
    return Math.floor(Math.random() * 101); // Random marks between 0-100
  };

  const getProgress = (courseId) => {
    // This function returns the progress percentage for a course
    // For now, it returns a random progress as a placeholder
    return Math.floor(Math.random() * 101); // Random progress between 0-100
  };

  return (
    <div className="profile-container">
      <h1>Profile</h1>
      <div className="user-info">
        <p><strong>Name:</strong> {user ? user.username : 'Guest'}</p>
      </div>

      <div className="marks-section">
        <h2>View Marks</h2>
        <table>
          <thead>
            <tr>
              <th>Course</th>
              <th>Marks</th>
            </tr>
          </thead>
          <tbody>
            {enrolledCourses.map((course) => (
              <tr key={course.id}>
                <td>{course.title}</td>
                <td>{getMarks(course.id)}%</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="progress-section">
        <h2>Progress</h2>
        <table>
          <thead>
            <tr>
              <th>Course</th>
              <th>Progress</th>
            </tr>
          </thead>
          <tbody>
            {enrolledCourses.map((course) => (
              <tr key={course.id}>
                <td>{course.title}</td>
                <td>{getProgress(course.id)}%</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="unenroll-section">
        <h2>Enrolled Courses</h2>
        <ul>
          {enrolledCourses.map((course) => (
            <li key={course.id}>
              {course.title}
              <p></p>
              <button onClick={() => unenrollFromCourse(course.id)}>Unenroll</button>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default Profile;
