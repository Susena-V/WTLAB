import React from 'react';
import { Link } from 'react-router-dom';
import '../styles.css';
import "./Header.css";

function Header({ isAuthenticated, handleLogout }) {
  return (
    <header>
      <nav>
        <Link to="/courses">Courses</Link>
        {isAuthenticated ? (
          <>
            <Link to="/profile">Profile</Link>
            <button onClick={handleLogout}>Logout</button>
          </>
        ) : (
          <>
            <Link to="/signup">Signup</Link>
            <Link to="/login">Login</Link>
          </>
        )}
      </nav>
    </header>
  );
}

export default Header;
