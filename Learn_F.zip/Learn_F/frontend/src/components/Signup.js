import React, { useState } from 'react';
import '../styles.css';  // Global styles
import './Forms.css';    // Specific form styles

function Signup({ handleLogin }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();

    // Get the existing users from localStorage
    const users = JSON.parse(localStorage.getItem('users')) || [];

    // Check if the username already exists
    if (users.some(user => user.username === username)) {
      setError('Username already taken');
      return;
    }

    // Store the new user in localStorage
    const newUser = { username, password };
    users.push(newUser);
    localStorage.setItem('users', JSON.stringify(users));

    // Automatically log the user in after signup
    handleLogin(newUser);

    // Clear the form fields and error
    setUsername('');
    setPassword('');
    setError('');
  };

  return (
    <div className="signup-container">
      <h2>Sign Up</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <input
            type="text"
            placeholder="Username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>
        {error && <p style={{ color: 'red' }}>{error}</p>}
        <button type="submit">Sign Up</button>
      </form>
    </div>
  );
}

export default Signup;
